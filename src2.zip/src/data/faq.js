/**
 * ============================================================
 * Fateh Music Academy
 * faq.js
 * Enterprise Edition v1.0
 *
 * Dynamic FAQ Generator
 * ============================================================
 */


import { courses } from "./courses.js";

import { instructors } from "./instructors.js";

import { schedules } from "./schedule.js";

import { pricing } from "./pricing.js";

import { contact } from "./contact.js";



/*
============================================================
Helper Functions
============================================================
*/


function getInstructor(course)
{

    const instructorId =
        course.instructorId;


    return instructors.find(
        instructor =>
        instructor.id === instructorId
    );

}



function getSchedule(instructorId)
{

    return schedules.find(
        item =>
        item.instructorId === instructorId &&
        item.active
    );

}



function getPricing(courseId)
{

    const pricingType =
        pricing.coursePricingMap[courseId];


    return pricing.types[pricingType];

}




/*
============================================================
Dynamic FAQ Builder
============================================================
*/


export function generateCourseFAQ(courseId)
{


const course =
courses.find(
item =>
item.id === courseId
);



if(!course)
return [];



const instructor =
getInstructor(course);



const schedule =
getSchedule(
instructor.id
);



const price =
getPricing(
course.id
);



return [


{


question:

`دوره آموزش ${course.title} چگونه برگزار می‌شود؟`,



answer:

`دوره آموزش ${course.title} در آموزشگاه موسیقی فاتح به صورت ${price.sessions} جلسه‌ای و طی ${price.duration} برگزار می‌شود. کلاس توسط استاد ${instructor.name} برگزار شده و امکان پرداخت ${price.paymentText} وجود دارد. هزینه کامل دوره ${price.fullPrice} تومان و هزینه نیم‌ترم ${price.halfPrice} تومان است.`


},



{


question:

`کلاس ${course.title} چه روزی برگزار می‌شود؟`,



answer:

`کلاس ${course.title} توسط استاد ${instructor.name} در روز ${schedule.weekday} برگزار می‌شود.`


},



{


question:

`هزینه کلاس ${course.title} چقدر است؟`,



answer:

`هزینه کامل دوره ${course.fullPrice} تومان است و امکان پرداخت نیم‌ترم با مبلغ ${course.halfPrice} تومان وجود دارد.`


}


];


}